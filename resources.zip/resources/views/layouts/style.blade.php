<link href="{{asset('assets/dist/libs/selectize/dist/css/selectize.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="{{asset('assets/dist/css/bootstrap.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
<link href="{{asset('assets/dist/libs/flatpickr/dist/flatpickr.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/libs/jqvmap/dist/jqvmap.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-flags.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-payments.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-vendors.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/demo.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">




<style>
  body {
    display: none;
  }

  .grid-container {
    display: grid;
    grid-template-columns: auto 1fr;
    /* background-color: aqua; */
  }

  .grid-item {
    /* background-color: rgba(255, 255, 255, 0.8); */
    /* border: 1px solid rgba(0, 0, 0, 0.8); */
    /* padding: 20px;
    font-size: 30px;
    text-align: center; */
    margin-left: 5px;
  }

  #chartdiv {
    width: 100%;
    height: 200px;
  }

  .warnaputih {
    color: white;
  }

  div.dataTables_wrapper div.dataTables_length select {
    width: 50px !important;
    display: inline-block;
  }
</style>